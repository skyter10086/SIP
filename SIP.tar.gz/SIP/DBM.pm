#!/usr/bin/env perl

### File: DBM.pm
### Descript: Role of Entity，about DB Operats
### Author: zby
### Date: 2017-05-19 fri

package SIP::DBM;

use strict;
use warnings;
use utf8::all;

use Moose::Role;
use SIP::DB;

requires 'set_table','set_schema';


my $db_source = {
  datasource => "dbi:SQLite:dbname='database.db'",
  usrname => '',
  pwd => '',
  attr => '',
  tbname => $table_name,
  schema => $table_schema,
};

my $db = SIP::DB->new($db_source);


sub save {
  my $self = shift;
  my @keys = $self->SUPER::meta()->get_attribute_list;
  my $hr = {};
  foreach my $k (@keys){
    $hr->{$k} = $self->$k;
  }
  $db->insrt($hr);

}

sub get {
  my ($self,$ref_filt) = @_;
  my $reslt = $db->fetch($ref_filt);
  
  

}
1;