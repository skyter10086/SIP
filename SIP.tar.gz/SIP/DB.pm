#!/usr/bin/env perl
package SIP::DB;
use DBI;
use utf8::all;
use strict;
use warnings;



  my ($dbh, $sth,$tbn,$tb_schema);
  sub init_tab;
  sub new {
    my $class = shift;
    my $self = shift ;
    $tbn = $self->{tbname};
    $tb_schema = $self->{schema};
    $dbh = DBI->connect($self->{data_source}, $self->{usrname},
           $self->{pwd}, $self->{attr}) or  die " DBI::errstr \n" ;
    init_tab($tb_schema) unless $sth = $dbh->table_info('%', '', $tbn,'TABLE') ;

    bless $self, $class ;
    return $self;
  }

  sub insrt {
    my ($self, $hash) = @_ ;
    my $kstr = join(", ", keys %$hash);
    my $vstr = join(", ", values %$hash);
    my $ststr = sprintf("INSERT INTO %s (%s) VALUES (%s)",$tbn,$kstr,$vstr);
    $sth = $dbh->prepare($ststr);
    $sth->execute or die "Can not insert values to table!\n$sth->errstr\n";
    $sth = undef;
    return 1; 
  
}  

sub fetch {
	my ($self, $id) = @_ ;
	$sth = $dbh->prepare(qq{SELECT * FROM ? WHERE id_num = ?}) ;
	my $rv=$sth->excute($tbn,$id) or die "Fetch data exception: $sth->errstr \n";
	

}

sub init_tab {
  my $schema = shift;
  $sth=$dbh->prepare($schema) ; 
  my $rv=$sth->execute() or die "$sth->errstr \n";



}
  
















1;

